E-Business: elines.coscoshipping.com PORT TO PORT OR COMBINED TRANSPORT BILL OF LADING
1. Shipper           Insert Name Address and Phone/Fax SMART DREAMERS TRADING & LOGISTICS CO., LTD. YADANA ROAD, NO.(1), ROOM (103), 1ST FLOOR, TET LAN HOUSING,10/SOUTH 12/QTR, THAKATA T/S,YANGON,MYANMAR. 

2. Consignee       Insert Name Address and Phone/Fax CHENZHOU FEIFAN CRAFTS CO., LTD GROUP 20, MEITIAN VILLAGE, MEITIAN TOWN, YIZHANG COUNTY, CHENZHOU CITY,HUNAN PROVINCE - CHINA 380925450@QQ.COM, TEL:18617142004 

3. Notify Party     Insert Name Address and Phone/Fax
                                                             (It is agreed that no responsibility shall attach
                                                             to the Carrier or his agents for failure to notify)
                                                                                                                   Also Notify Party-routing & Instructions

CHENZHOU FEIFAN CRAFTS CO., LTD 
GROUP 20, MEITIAN VILLAGE, MEITIAN 
TOWN, YIZHANG COUNTY, CHENZHOU 
CITY,HUNAN PROVINCE - CHINA 
380925450@QQ.COM, TEL:18617142004 

## 4. Combined Transport *      Pre-Carriage By 5. Combined Transport *     Place Of Receipt Yangon,Myanmar

7. Port of Loading No. of Container or Packages Description of Goods (if Dangerous Goods, See Clause 20)
Gross Weight Measurement N/M                      517 GEBANG PALM SEED FOR ORNAMENT       27005.000KGS   60.0000CBM BAGS TOTAL :( 517 ) BAGS NW : 26,488.00 KGS --------------------------------------------------------------------------------------------- OCEAN FREIGHT PREPAID SHIPPER'S LOAD STOW COUNT AND SEAL ON CY-CY TERM --------------------------------------------------------------------------------------------- TCKU6202503  /25901346     /    517 BAGS          /FCL/FCL /40HQ/                          

Description of Contents for Shipper's Use Only (Not part of This B/L Contract)
10. Total Number of Containers and/or Packages (in words) Subject to Clause 7 Limitation
SAY ONE CONTAINER TOTAL
11.        Freight & Charges
Revenue Tons
Rate
Per
Amount
Prepaid
Collect
Freight & Charges Payable at / by

Received in external apparent good order and condition except as otherwise noted. The total number of the packages or units stuffed in the container, the description of the goods and the weights shown in this Bill of Lading are furnished by the merchants, and which the carrier has no reasonable means of checking and is not a part of this Bills of Lading contract. 

The carrier has issued  1  original Bills of Lading, all of this tenor and date, one of the original Bills of Lading must be surrendered and endorsed or signed against the delivery of the shipment and whereupon any other original Bills of Lading shall be void. The merchants agree to be bound by the terms and conditions of this Bill of Lading as if each had personally signed this Bill of Lading. *Applicable Only When Document Used as a Combined Transport Bill of Lading. Demurrage and Detention shall be charged according to the tariff published on the Home page of http://lines.coscoshipping. com. If any ambiguity or query, please search by Demurrage & Detention Tariff Enquiry. The complete TERMS AND CONDITIONS appearing on the reverse side of this Bill of Lading are available at http://lines.coscoshipping.com, which also provides other services and more detailed information.

  
                                                                                                       
Booking No.

7244522200 
Export References CSO/AGREEMENT NUMBER 00031156 